/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.parsexml;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper; 
import com.mycompany.parsexml.myPojo.Root;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 *
 * @author admin
 */
public class ParseXML {

    public static void main(String[] args) throws JsonProcessingException, IOException {
           System.out.println("Deserializing from XML...");
        deserializeFromXML();

    }
 

    public static void deserializeFromXML() {
        try {
            XmlMapper xmlMapper = new XmlMapper();

            String readContent = new String(Files.readAllBytes(Paths.get("C:\\Users\\admin\\Downloads\\data (1).xml")));
            System.out.println("what  us" + readContent);
            Root deserializedData = xmlMapper.readValue(readContent, Root.class);

            System.out.println("Deserialized data: ");
            System.out.println(deserializedData.getChildPlusDataExport());
        } catch (IOException e) {
        }
    }
}
