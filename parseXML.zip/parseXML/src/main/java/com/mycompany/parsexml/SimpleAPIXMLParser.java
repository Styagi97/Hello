/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml;
 
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;

/**
 *
 * @author admin
 */
public class SimpleAPIXMLParser {
    
    public static void main(String[] args) throws IOException {
        try {
            File  file=new File("C:\\Users\\admin\\Documents\\Shivani\\sample.txt");
            SAXParserFactory aXParserFactory=SAXParserFactory.newInstance();
             SAXParser aXParser=aXParserFactory.newSAXParser();
            UserHandler userhandler = new UserHandler();
            aXParser.parse(file, userhandler);
        } catch (ParserConfigurationException | SAXException e) {
        }
    }
}
