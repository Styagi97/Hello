/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import org.dom4j.DocumentException;

/**
 *
 * @author admin
 */
public class StAXParser {

    public static void main(String[] args) throws XMLStreamException, FileNotFoundException, DocumentException {
           printXmlByXmlCursorReader(Paths.get("C:\\Users\\admin\\Downloads\\Sample_Data.xml"));
 
}

    private static void printXmlByXmlCursorReader(Path path) throws FileNotFoundException, XMLStreamException {
        XMLInputFactory xMLInputFactory = XMLInputFactory.newInstance();

        XMLStreamReader reader = xMLInputFactory.createXMLStreamReader(
                new FileInputStream(path.toFile()));

        // this is int! we need to map the eventType manually
        int eventType = reader.getEventType();

        while (reader.hasNext()) {

            eventType = reader.next();

            if (eventType == XMLEvent.START_ELEMENT) {
                switch (reader.getName().getLocalPart()) {

                    case "CodeType" -> {
                        String id = reader.getAttributeValue(null, "CodeType");
                        System.out.printf("CodeType id : %s%n", id);
                        break;
                    }

                    case "Description" -> {
                        eventType = reader.next();
                        if (eventType == XMLEvent.CHARACTERS) {
                            System.out.printf("Description : %s%n", reader.getText());
                        }
                        break;
                    }

                    case "UserMaintainable" -> {
                        eventType = reader.next();
                        if (eventType == XMLEvent.CHARACTERS) {
                            System.out.printf("UserMaintainable : %s%n", reader.getText());
                        }
                        break;
                    }

                    case "Code" -> {
                        String currency = reader.getAttributeValue(null, "CodeID");
                        eventType = reader.next();
                        if (eventType == XMLEvent.CHARACTERS) {

                            System.out.printf("CodeID : %s%n", currency);
                        }
                        break;
                    }

                    case "SystemDefined" -> {
                        eventType = reader.next();
                        if (eventType == XMLEvent.CHARACTERS) {
                            System.out.printf("SystemDefined : %s%n", reader.getText());
                        }
                        break;
                    }
                }

            }

        }
    }
 
}
