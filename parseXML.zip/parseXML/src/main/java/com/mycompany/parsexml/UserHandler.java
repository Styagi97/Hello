/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author admin
 */
public class UserHandler extends DefaultHandler {

//    private boolean bName = false;
//    private boolean bPersonID = false;
//    private boolean bResponsibleStaffID = false;
//    private boolean cName;
//    private boolean bDue3 = false;
//    private boolean bDue2 = false;
//    private boolean bDue1 = false;
//    private boolean bExempt=false;
    private boolean bProgramID = false;
    private boolean bProgram = false;
    private boolean bProgramTerm = false;
    private boolean bProgramTermID = false;
    private boolean bStatus = false;
    private boolean bStatusDate = false;
    private boolean bAgencyID = false;
    private boolean bAgency = false;
    private boolean bSiteID = false;
    private boolean bSite = false;
    private boolean bClassroomID = false;
    private boolean bClassroom = false;
    private boolean bOriginalEnrollmentDate = false;
    private boolean bEntryDate = false;
    private boolean bPersonID = false;
    private boolean bParticipationID=false;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (qName.equalsIgnoreCase("Participation")) {
            String bookId = attributes.getValue("ParticipationID");
            System.out.println("ParticipationID:" + bookId);
        } else if (qName.equalsIgnoreCase("PersonID")) {
            bPersonID = true;
        } else if (qName.equalsIgnoreCase("ProgramID")) {
            bProgramID = true;
        } else if (qName.equalsIgnoreCase("Program")) {
            bProgram = true;
        } else if (qName.equalsIgnoreCase("ProgramTerm")) {
            bProgramTerm = true;
        } else if (qName.equalsIgnoreCase("ProgramTermID")) {
            bProgramTermID = true;
        } 
        else if(qName.equalsIgnoreCase("ParticipationID")){
            bParticipationID=true;
        }
        else if (qName.equalsIgnoreCase("Status")) {
            bStatus = true;
        } else if (qName.equalsIgnoreCase("StatusDate")) {
            bStatusDate = true;
        } else if (qName.equalsIgnoreCase("AgencyID")) {
            bAgencyID = true;
        } else if (qName.equalsIgnoreCase("Agency")) {
            bAgency = true;
        }else if (qName.equalsIgnoreCase("SiteID")) {
            bSiteID = true;
        } else if (qName.equalsIgnoreCase("Site")) {
            bSite = true;
        } else if (qName.equalsIgnoreCase("ClassroomID")) {
            bClassroomID = true;
        } else if (qName.equalsIgnoreCase("Classroom")) {
            bClassroom = true;
        } else if (qName.equalsIgnoreCase("OriginalEnrollmentDate")) {
            bOriginalEnrollmentDate = true;
        } else if (qName.equalsIgnoreCase("EntryDate")) {
            bEntryDate = true;
        }

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
       
        if (bPersonID) {
            System.out.println("PersonID : " + new String(ch, start, length));
            bPersonID = false;
        }
        if (bProgramID) {
            System.out.println("ProgramID : " + new String(ch, start, length));
            bProgramID = false;
        }
        if (bProgram) {
            System.out.println("Program :" + new String(ch, start, length));
            bProgram = false;
        }
        if (bProgramTerm) {
            System.out.println("ProgramTerm : " + new String(ch, start, length));
            bProgramTerm = false;
        }
        if (bProgramTermID) {
            System.out.println("ProgramTermID : " + new String(ch, start, length));
            bProgramTermID = false;
        }
        if (bParticipationID) {
            System.out.println("bParticipationID : " + new String(ch, start, length));
            bParticipationID = false;
        }
        if (bStatus) {
            System.out.println("Status : " + new String(ch, start, length));
            bStatus = false;
        }
           if (bStatusDate) {
            System.out.println("bStatusDate : " + new String(ch, start, length));
            bStatusDate = false;
        }
        if (bAgencyID) {
            System.out.println("bAgencyID : " + new String(ch, start, length));
            bAgencyID = false;
        }
        if (bAgency) {
            System.out.println("bAgency " + new String(ch, start, length));
            bAgency = false;
        }
        if (bSiteID) {
            System.out.println("SiteID : " + new String(ch, start, length));
            bSiteID = false;
        }
        if (bSite) {
            System.out.println("Site : " + new String(ch, start, length));
            bSite = false;
        }
         if (bClassroomID) {
            System.out.println("bClassroomID : " + new String(ch, start, length));
            bClassroomID = false;
        }
        if (bClassroom) {
            System.out.println("bClassroom : " + new String(ch, start, length));
            bClassroom = false;
        }
         if (bOriginalEnrollmentDate) {
            System.out.println("bOriginalEnrollmentDate : " + new String(ch, start, length));
            bOriginalEnrollmentDate = false;
        }
        if (bEntryDate) {
            System.out.println("bEntryDate : " + new String(ch, start, length));
            bEntryDate = false;
        }
    }

}
