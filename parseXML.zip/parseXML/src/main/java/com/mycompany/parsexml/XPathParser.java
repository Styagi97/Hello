/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author admin
 */
public class XPathParser {

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
        File inputFile = new File("C:\\Users\\admin\\Downloads\\Sample_Data.xml");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;

        dBuilder = dbFactory.newDocumentBuilder();

        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();

        XPath xPath = XPathFactory.newInstance().newXPath();

        String expression = "/ChildPlusDataExport/Codes/CodeType";
        NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(doc, XPathConstants.NODESET);
        System.out.println(nodeList);
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node nNode = nodeList.item(i);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                System.out.println("CodeType :" + eElement.getAttribute("CodeType"));
                System.out.println("Description : " + eElement.getElementsByTagName("Description").item(0).getTextContent());
                System.out.println("UserMaintainable : " + eElement.getElementsByTagName("UserMaintainable").item(0).getTextContent());
                String expression1 = "/ChildPlusDataExport/Codes/CodeType/Code";
                NodeList nodeList1 = (NodeList) xPath.compile(expression1).evaluate(doc, XPathConstants.NODESET);

                for (int j = 0; j < nodeList1.getLength(); j++) {
                    Node nNode1 = nodeList1.item(j);
                    System.out.println("\nCurrent Element :" + nNode.getNodeName());

                    if (nNode1.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement1 = (Element) nNode1;
                        System.out.println("CodeID :" + eElement1.getAttribute("CodeID"));
                        System.out.println("Code: " + eElement1.getElementsByTagName("Code").item(0).getTextContent());
                        System.out.println("CodeType : " + eElement1.getElementsByTagName("CodeType").item(0).getTextContent());
                        System.out.println("Description : " + eElement1.getElementsByTagName("Description").item(0).getTextContent());
                        System.out.println("SystemDefined : " + eElement1.getElementsByTagName("SystemDefined").item(0).getTextContent());
                        System.out.println("Actid : " + eElement1.getElementsByTagName("Actid").item(0).getTextContent());
                        System.out.println("Active : " + eElement1.getElementsByTagName("Active").item(0).getTextContent());

                    }
                }
            }
        }
    }
}
