/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.bean;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Orders {
   private List<Order> order = new ArrayList<>();
    private List<String> content = new ArrayList<>();   

    public List<Order> getOrder() {
        return order;
    }

    public void setOrder(List<Order> order) {
        this.order = order;
    }

    public List<String> getContent() {
        return content;
    }

    public void setContent(List<String> content) {
        this.content = content;
    }
    
}
