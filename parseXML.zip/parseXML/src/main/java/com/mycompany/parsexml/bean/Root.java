/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.bean;

/**
 *
 * @author admin
 */
public class Root {
    private Root_ root;

    public Root_ getRoot() {
        return root;
    }

    public void setRoot(Root_ root) {
        this.root = root;
    }
    
}
