/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class ChildPlusDataExport {

    private String agencyName;
    private String childPlusVersion;
    private SiteInspectionSetup siteInspectionSetup;
    private Codes codes;
    private FamilyApplications familyApplications;
    private Locations locations;
    private String publicDatabaseID;
    private UserDefinedFields userDefinedFields;
    private Participants participants;
    private Personnel personnel;

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getChildPlusVersion() {
        return childPlusVersion;
    }

    public void setChildPlusVersion(String childPlusVersion) {
        this.childPlusVersion = childPlusVersion;
    }

    public SiteInspectionSetup getSiteInspectionSetup() {
        return siteInspectionSetup;
    }

    public void setSiteInspectionSetup(SiteInspectionSetup siteInspectionSetup) {
        this.siteInspectionSetup = siteInspectionSetup;
    }

    public Codes getCodes() {
        return codes;
    }

    public void setCodes(Codes codes) {
        this.codes = codes;
    }

    public FamilyApplications getFamilyApplications() {
        return familyApplications;
    }

    public void setFamilyApplications(FamilyApplications familyApplications) {
        this.familyApplications = familyApplications;
    }

    public Locations getLocations() {
        return locations;
    }

    public void setLocations(Locations locations) {
        this.locations = locations;
    }

    public String getPublicDatabaseID() {
        return publicDatabaseID;
    }

    public void setPublicDatabaseID(String publicDatabaseID) {
        this.publicDatabaseID = publicDatabaseID;
    }

    public UserDefinedFields getUserDefinedFields() {
        return userDefinedFields;
    }

    public void setUserDefinedFields(UserDefinedFields userDefinedFields) {
        this.userDefinedFields = userDefinedFields;
    }

    public Participants getParticipants() {
        return participants;
    }

    public void setParticipants(Participants participants) {
        this.participants = participants;
    }

    public Personnel getPersonnel() {
        return personnel;
    }

    public void setPersonnel(Personnel personnel) {
        this.personnel = personnel;
    }
    
}
