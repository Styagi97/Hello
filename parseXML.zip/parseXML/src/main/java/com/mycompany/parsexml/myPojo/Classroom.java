/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Classroom {
      private String siteID;
    private Integer active;
    private String programTermClassroomID;
    private String className;
    private String classroomLabel;
    private String programTermID;
    private String programTermName;
    private Integer classCapacity;
    private Integer endDate;
    private String classroomID;
    private Integer beginDate;
    private List<ClassroomTeacher> classroomTeacher = new ArrayList<>();
    private String endTime;
    private String beginTime;
    private ClassroomAide classroomAide;
    private Integer maxAgeMonths;
    private Integer minAgeMonths;
    private Integer minAgeYears;
    private Integer maxAgeYears;

    public String getSiteID() {
        return siteID;
    }

    public void setSiteID(String siteID) {
        this.siteID = siteID;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    public String getProgramTermClassroomID() {
        return programTermClassroomID;
    }

    public void setProgramTermClassroomID(String programTermClassroomID) {
        this.programTermClassroomID = programTermClassroomID;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassroomLabel() {
        return classroomLabel;
    }

    public void setClassroomLabel(String classroomLabel) {
        this.classroomLabel = classroomLabel;
    }

    public String getProgramTermID() {
        return programTermID;
    }

    public void setProgramTermID(String programTermID) {
        this.programTermID = programTermID;
    }

    public String getProgramTermName() {
        return programTermName;
    }

    public void setProgramTermName(String programTermName) {
        this.programTermName = programTermName;
    }

    public Integer getClassCapacity() {
        return classCapacity;
    }

    public void setClassCapacity(Integer classCapacity) {
        this.classCapacity = classCapacity;
    }

    public Integer getEndDate() {
        return endDate;
    }

    public void setEndDate(Integer endDate) {
        this.endDate = endDate;
    }

    public String getClassroomID() {
        return classroomID;
    }

    public void setClassroomID(String classroomID) {
        this.classroomID = classroomID;
    }

    public Integer getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Integer beginDate) {
        this.beginDate = beginDate;
    }

    public List<ClassroomTeacher> getClassroomTeacher() {
        return classroomTeacher;
    }

    public void setClassroomTeacher(List<ClassroomTeacher> classroomTeacher) {
        this.classroomTeacher = classroomTeacher;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }

    public ClassroomAide getClassroomAide() {
        return classroomAide;
    }

    public void setClassroomAide(ClassroomAide classroomAide) {
        this.classroomAide = classroomAide;
    }

    public Integer getMaxAgeMonths() {
        return maxAgeMonths;
    }

    public void setMaxAgeMonths(Integer maxAgeMonths) {
        this.maxAgeMonths = maxAgeMonths;
    }

    public Integer getMinAgeMonths() {
        return minAgeMonths;
    }

    public void setMinAgeMonths(Integer minAgeMonths) {
        this.minAgeMonths = minAgeMonths;
    }

    public Integer getMinAgeYears() {
        return minAgeYears;
    }

    public void setMinAgeYears(Integer minAgeYears) {
        this.minAgeYears = minAgeYears;
    }

    public Integer getMaxAgeYears() {
        return maxAgeYears;
    }

    public void setMaxAgeYears(Integer maxAgeYears) {
        this.maxAgeYears = maxAgeYears;
    }
    
}
