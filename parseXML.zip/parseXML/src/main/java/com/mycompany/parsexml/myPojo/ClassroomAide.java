/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class ClassroomAide {
     private String programTermClassroomID;
    private String personID;
    private String classroomID;
    private String name;

    public String getProgramTermClassroomID() {
        return programTermClassroomID;
    }

    public void setProgramTermClassroomID(String programTermClassroomID) {
        this.programTermClassroomID = programTermClassroomID;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getClassroomID() {
        return classroomID;
    }

    public void setClassroomID(String classroomID) {
        this.classroomID = classroomID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
