/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class CodeType {
    private String description;
    private Integer userMaintainable;
    private String codeType;
    private List<Code> code = new ArrayList<>();

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getUserMaintainable() {
        return userMaintainable;
    }

    public void setUserMaintainable(Integer userMaintainable) {
        this.userMaintainable = userMaintainable;
    }

    public String getCodeType() {
        return codeType;
    }

    public void setCodeType(String codeType) {
        this.codeType = codeType;
    }

    public List<Code> getCode() {
        return code;
    }

    public void setCode(List<Code> code) {
        this.code = code;
    }
    
     
}
