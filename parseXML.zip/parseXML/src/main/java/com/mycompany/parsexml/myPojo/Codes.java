/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Codes {

    private List<CodeType> codeType = new ArrayList<>();

    public List<CodeType> getCodeType() {
        return codeType;
    }

    public void setCodeType(List<CodeType> codeType) {
        this.codeType = codeType;
    }
 
}
