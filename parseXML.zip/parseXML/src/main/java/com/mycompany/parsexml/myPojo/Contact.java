/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Contact {
     private Integer zip;
    private Integer emergencyContact;
    private String address2;
    private Integer doNotReleaseTo;
    private String relationToFamilyCodeID;
    private String contactID;
    private Integer releaseTo;
    private String city;
    private String address1;
    private String name;
    private List<ContactPhone> contactPhone = new ArrayList<>();
    private String familyID;
    private String state;
    private Integer contactNumber;
    private String relationToFamily;

    public Integer getZip() {
        return zip;
    }

    public void setZip(Integer zip) {
        this.zip = zip;
    }

    public Integer getEmergencyContact() {
        return emergencyContact;
    }

    public void setEmergencyContact(Integer emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public Integer getDoNotReleaseTo() {
        return doNotReleaseTo;
    }

    public void setDoNotReleaseTo(Integer doNotReleaseTo) {
        this.doNotReleaseTo = doNotReleaseTo;
    }

    public String getRelationToFamilyCodeID() {
        return relationToFamilyCodeID;
    }

    public void setRelationToFamilyCodeID(String relationToFamilyCodeID) {
        this.relationToFamilyCodeID = relationToFamilyCodeID;
    }

    public String getContactID() {
        return contactID;
    }

    public void setContactID(String contactID) {
        this.contactID = contactID;
    }

    public Integer getReleaseTo() {
        return releaseTo;
    }

    public void setReleaseTo(Integer releaseTo) {
        this.releaseTo = releaseTo;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ContactPhone> getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(List<ContactPhone> contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getFamilyID() {
        return familyID;
    }

    public void setFamilyID(String familyID) {
        this.familyID = familyID;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(Integer contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getRelationToFamily() {
        return relationToFamily;
    }

    public void setRelationToFamily(String relationToFamily) {
        this.relationToFamily = relationToFamily;
    }
    
}
