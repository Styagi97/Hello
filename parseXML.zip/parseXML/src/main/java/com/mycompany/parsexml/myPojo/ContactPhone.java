/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class ContactPhone {
      private String phone;
    private String contactID;
    private String phoneTypeCodeID;
    private String phoneType;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getContactID() {
        return contactID;
    }

    public void setContactID(String contactID) {
        this.contactID = contactID;
    }

    public String getPhoneTypeCodeID() {
        return phoneTypeCodeID;
    }

    public void setPhoneTypeCodeID(String phoneTypeCodeID) {
        this.phoneTypeCodeID = phoneTypeCodeID;
    }

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }
    
    
}
