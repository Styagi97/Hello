/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class Enrollment {
     private String status;
    private String site;
    private Integer statusDate;
    private String siteID;
    private String agency;
    private String agencyID;
    private String classroom;
    private Integer entryDate;
    private Integer originalEnrollmentDate;
    private String participationID;
    private String classroomID;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public Integer getStatusDate() {
        return statusDate;
    }

    public void setStatusDate(Integer statusDate) {
        this.statusDate = statusDate;
    }

    public String getSiteID() {
        return siteID;
    }

    public void setSiteID(String siteID) {
        this.siteID = siteID;
    }

    public String getAgency() {
        return agency;
    }

    public void setAgency(String agency) {
        this.agency = agency;
    }

    public String getAgencyID() {
        return agencyID;
    }

    public void setAgencyID(String agencyID) {
        this.agencyID = agencyID;
    }

    public String getClassroom() {
        return classroom;
    }

    public void setClassroom(String classroom) {
        this.classroom = classroom;
    }

    public Integer getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Integer entryDate) {
        this.entryDate = entryDate;
    }

    public Integer getOriginalEnrollmentDate() {
        return originalEnrollmentDate;
    }

    public void setOriginalEnrollmentDate(Integer originalEnrollmentDate) {
        this.originalEnrollmentDate = originalEnrollmentDate;
    }

    public String getParticipationID() {
        return participationID;
    }

    public void setParticipationID(String participationID) {
        this.participationID = participationID;
    }

    public String getClassroomID() {
        return classroomID;
    }

    public void setClassroomID(String classroomID) {
        this.classroomID = classroomID;
    }
}
