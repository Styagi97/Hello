/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class FamilyApplication {
      private String tANFStatusCodeID;
    private Integer physicalZip1;
    private String parentTypeCodeID;
    private String verificationDate;
    private String familyName;
    private FamilyPhone familyPhone;
    private String primaryLanguageAtHomeCodeID;
    private String physicalAddress2;
    private Integer numberInFamily;
    private String physicalAddress1;
    private String tANFStatus;
    private String familyNumber;
    private String physicalCounty;
    private Integer socialSecurityIncome;
    private String physicalState;
    private String primaryLanguageAtHome;
    private List<FamilyMember> familyMember = new ArrayList<>();
    private String familyID;
    private String parentType;
    private Integer childPlusFamilyID;
    private Integer numberInHousehold;
    private Integer physicalZip;
    private String physicalCity;
    private Integer mailSameAsPhysical;
    private Contact contact;
    private IncomeVerification incomeVerification;
    private Integer mailZip;
    private String mailState;
    private String mailCity;
    private String mailAddress1;
    private String mailAddress2;
    private String verifiedByPersonID;
    private VerifiedBy verifiedBy;
    private String incomeNotes;

    public String gettANFStatusCodeID() {
        return tANFStatusCodeID;
    }

    public void settANFStatusCodeID(String tANFStatusCodeID) {
        this.tANFStatusCodeID = tANFStatusCodeID;
    }

    public Integer getPhysicalZip1() {
        return physicalZip1;
    }

    public void setPhysicalZip1(Integer physicalZip1) {
        this.physicalZip1 = physicalZip1;
    }

    public String getParentTypeCodeID() {
        return parentTypeCodeID;
    }

    public void setParentTypeCodeID(String parentTypeCodeID) {
        this.parentTypeCodeID = parentTypeCodeID;
    }

    public String getVerificationDate() {
        return verificationDate;
    }

    public void setVerificationDate(String verificationDate) {
        this.verificationDate = verificationDate;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public FamilyPhone getFamilyPhone() {
        return familyPhone;
    }

    public void setFamilyPhone(FamilyPhone familyPhone) {
        this.familyPhone = familyPhone;
    }

    public String getPrimaryLanguageAtHomeCodeID() {
        return primaryLanguageAtHomeCodeID;
    }

    public void setPrimaryLanguageAtHomeCodeID(String primaryLanguageAtHomeCodeID) {
        this.primaryLanguageAtHomeCodeID = primaryLanguageAtHomeCodeID;
    }

    public String getPhysicalAddress2() {
        return physicalAddress2;
    }

    public void setPhysicalAddress2(String physicalAddress2) {
        this.physicalAddress2 = physicalAddress2;
    }

    public Integer getNumberInFamily() {
        return numberInFamily;
    }

    public void setNumberInFamily(Integer numberInFamily) {
        this.numberInFamily = numberInFamily;
    }

    public String getPhysicalAddress1() {
        return physicalAddress1;
    }

    public void setPhysicalAddress1(String physicalAddress1) {
        this.physicalAddress1 = physicalAddress1;
    }

    public String gettANFStatus() {
        return tANFStatus;
    }

    public void settANFStatus(String tANFStatus) {
        this.tANFStatus = tANFStatus;
    }

    public String getFamilyNumber() {
        return familyNumber;
    }

    public void setFamilyNumber(String familyNumber) {
        this.familyNumber = familyNumber;
    }

    public String getPhysicalCounty() {
        return physicalCounty;
    }

    public void setPhysicalCounty(String physicalCounty) {
        this.physicalCounty = physicalCounty;
    }

    public Integer getSocialSecurityIncome() {
        return socialSecurityIncome;
    }

    public void setSocialSecurityIncome(Integer socialSecurityIncome) {
        this.socialSecurityIncome = socialSecurityIncome;
    }

    public String getPhysicalState() {
        return physicalState;
    }

    public void setPhysicalState(String physicalState) {
        this.physicalState = physicalState;
    }

    public String getPrimaryLanguageAtHome() {
        return primaryLanguageAtHome;
    }

    public void setPrimaryLanguageAtHome(String primaryLanguageAtHome) {
        this.primaryLanguageAtHome = primaryLanguageAtHome;
    }

    public List<FamilyMember> getFamilyMember() {
        return familyMember;
    }

    public void setFamilyMember(List<FamilyMember> familyMember) {
        this.familyMember = familyMember;
    }

    public String getFamilyID() {
        return familyID;
    }

    public void setFamilyID(String familyID) {
        this.familyID = familyID;
    }

    public String getParentType() {
        return parentType;
    }

    public void setParentType(String parentType) {
        this.parentType = parentType;
    }

    public Integer getChildPlusFamilyID() {
        return childPlusFamilyID;
    }

    public void setChildPlusFamilyID(Integer childPlusFamilyID) {
        this.childPlusFamilyID = childPlusFamilyID;
    }

    public Integer getNumberInHousehold() {
        return numberInHousehold;
    }

    public void setNumberInHousehold(Integer numberInHousehold) {
        this.numberInHousehold = numberInHousehold;
    }

    public Integer getPhysicalZip() {
        return physicalZip;
    }

    public void setPhysicalZip(Integer physicalZip) {
        this.physicalZip = physicalZip;
    }

    public String getPhysicalCity() {
        return physicalCity;
    }

    public void setPhysicalCity(String physicalCity) {
        this.physicalCity = physicalCity;
    }

    public Integer getMailSameAsPhysical() {
        return mailSameAsPhysical;
    }

    public void setMailSameAsPhysical(Integer mailSameAsPhysical) {
        this.mailSameAsPhysical = mailSameAsPhysical;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

    public IncomeVerification getIncomeVerification() {
        return incomeVerification;
    }

    public void setIncomeVerification(IncomeVerification incomeVerification) {
        this.incomeVerification = incomeVerification;
    }

    public Integer getMailZip() {
        return mailZip;
    }

    public void setMailZip(Integer mailZip) {
        this.mailZip = mailZip;
    }

    public String getMailState() {
        return mailState;
    }

    public void setMailState(String mailState) {
        this.mailState = mailState;
    }

    public String getMailCity() {
        return mailCity;
    }

    public void setMailCity(String mailCity) {
        this.mailCity = mailCity;
    }

    public String getMailAddress1() {
        return mailAddress1;
    }

    public void setMailAddress1(String mailAddress1) {
        this.mailAddress1 = mailAddress1;
    }

    public String getMailAddress2() {
        return mailAddress2;
    }

    public void setMailAddress2(String mailAddress2) {
        this.mailAddress2 = mailAddress2;
    }

    public String getVerifiedByPersonID() {
        return verifiedByPersonID;
    }

    public void setVerifiedByPersonID(String verifiedByPersonID) {
        this.verifiedByPersonID = verifiedByPersonID;
    }

    public VerifiedBy getVerifiedBy() {
        return verifiedBy;
    }

    public void setVerifiedBy(VerifiedBy verifiedBy) {
        this.verifiedBy = verifiedBy;
    }

    public String getIncomeNotes() {
        return incomeNotes;
    }

    public void setIncomeNotes(String incomeNotes) {
        this.incomeNotes = incomeNotes;
    }
    
}
