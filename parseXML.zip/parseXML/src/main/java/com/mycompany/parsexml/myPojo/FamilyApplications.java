/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class FamilyApplications {

    private List<FamilyApplication> familyApplication = new ArrayList<>();

    public List<FamilyApplication> getFamilyApplication() {
        return familyApplication;
    }

    public void setFamilyApplication(List<FamilyApplication> familyApplication) {
        this.familyApplication = familyApplication;
    }
}
