/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class FamilyMember {
      private Integer shareMailingAddress;
    private String raceCodeID;
    private String firstName;
    private String sex;
    private Integer isHispanic;
    private Integer teenParent;
    private Integer birthday;
    private Integer childPlusID;
    private String sharePhysicalAddressFamily;
    private String sSN;
    private LanguageProficiency languageProficiency;
    private String primarySecondary;
    private String personID;
    private Integer providesFinancialSupport;
    private String familyID;
    private String race;
    private String primarySecondaryCodeID;
    private String shareMailingAddressFamily;
    private String adultChildCodeID;
    private String lastName;
    private String adultChild;
    private String sexCodeID;
    private Integer sharePhysicalAddress;
    private Integer mailSameAsPhysical;
    private Integer releaseSignedDate;
    private Integer releaseSigned;
    private List<Relationship> relationship = new ArrayList<>();
    private String middleName;
    private List<PersonContact> personContact = new ArrayList<>();
    private String raceOtherDescription;
    private Integer subsidized;
    private GroupMembership groupMembership;
    private String nameSuffix;
    private List<UserDefinedValue> userDefinedValue = new ArrayList<>();
    private List<PersonPhone> personPhone = new ArrayList<>();
    private Integer mailZip;
    private String physicalAddress1;
    private String physicalCounty;
    private String mailState;
    private String mailCity;
    private String physicalCity;
    private Integer physicalZip;
    private String physicalState;
    private String mailAddress1;
    private String preferredName;
    private String shareMailingAddressFamilyID;
    private String sharePhysicalAddressFamilyID;
    private String schoolDistrictCodeID;
    private String schoolDistrict;
    private String notes;
    private String physicalAddress2;
    private String email;
    private Integer alternateID;

    public Integer getShareMailingAddress() {
        return shareMailingAddress;
    }

    public void setShareMailingAddress(Integer shareMailingAddress) {
        this.shareMailingAddress = shareMailingAddress;
    }

    public String getRaceCodeID() {
        return raceCodeID;
    }

    public void setRaceCodeID(String raceCodeID) {
        this.raceCodeID = raceCodeID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getIsHispanic() {
        return isHispanic;
    }

    public void setIsHispanic(Integer isHispanic) {
        this.isHispanic = isHispanic;
    }

    public Integer getTeenParent() {
        return teenParent;
    }

    public void setTeenParent(Integer teenParent) {
        this.teenParent = teenParent;
    }

    public Integer getBirthday() {
        return birthday;
    }

    public void setBirthday(Integer birthday) {
        this.birthday = birthday;
    }

    public Integer getChildPlusID() {
        return childPlusID;
    }

    public void setChildPlusID(Integer childPlusID) {
        this.childPlusID = childPlusID;
    }

    public String getSharePhysicalAddressFamily() {
        return sharePhysicalAddressFamily;
    }

    public void setSharePhysicalAddressFamily(String sharePhysicalAddressFamily) {
        this.sharePhysicalAddressFamily = sharePhysicalAddressFamily;
    }

    public String getsSN() {
        return sSN;
    }

    public void setsSN(String sSN) {
        this.sSN = sSN;
    }

    public LanguageProficiency getLanguageProficiency() {
        return languageProficiency;
    }

    public void setLanguageProficiency(LanguageProficiency languageProficiency) {
        this.languageProficiency = languageProficiency;
    }

    public String getPrimarySecondary() {
        return primarySecondary;
    }

    public void setPrimarySecondary(String primarySecondary) {
        this.primarySecondary = primarySecondary;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public Integer getProvidesFinancialSupport() {
        return providesFinancialSupport;
    }

    public void setProvidesFinancialSupport(Integer providesFinancialSupport) {
        this.providesFinancialSupport = providesFinancialSupport;
    }

    public String getFamilyID() {
        return familyID;
    }

    public void setFamilyID(String familyID) {
        this.familyID = familyID;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public String getPrimarySecondaryCodeID() {
        return primarySecondaryCodeID;
    }

    public void setPrimarySecondaryCodeID(String primarySecondaryCodeID) {
        this.primarySecondaryCodeID = primarySecondaryCodeID;
    }

    public String getShareMailingAddressFamily() {
        return shareMailingAddressFamily;
    }

    public void setShareMailingAddressFamily(String shareMailingAddressFamily) {
        this.shareMailingAddressFamily = shareMailingAddressFamily;
    }

    public String getAdultChildCodeID() {
        return adultChildCodeID;
    }

    public void setAdultChildCodeID(String adultChildCodeID) {
        this.adultChildCodeID = adultChildCodeID;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAdultChild() {
        return adultChild;
    }

    public void setAdultChild(String adultChild) {
        this.adultChild = adultChild;
    }

    public String getSexCodeID() {
        return sexCodeID;
    }

    public void setSexCodeID(String sexCodeID) {
        this.sexCodeID = sexCodeID;
    }

    public Integer getSharePhysicalAddress() {
        return sharePhysicalAddress;
    }

    public void setSharePhysicalAddress(Integer sharePhysicalAddress) {
        this.sharePhysicalAddress = sharePhysicalAddress;
    }

    public Integer getMailSameAsPhysical() {
        return mailSameAsPhysical;
    }

    public void setMailSameAsPhysical(Integer mailSameAsPhysical) {
        this.mailSameAsPhysical = mailSameAsPhysical;
    }

    public Integer getReleaseSignedDate() {
        return releaseSignedDate;
    }

    public void setReleaseSignedDate(Integer releaseSignedDate) {
        this.releaseSignedDate = releaseSignedDate;
    }

    public Integer getReleaseSigned() {
        return releaseSigned;
    }

    public void setReleaseSigned(Integer releaseSigned) {
        this.releaseSigned = releaseSigned;
    }

    public List<Relationship> getRelationship() {
        return relationship;
    }

    public void setRelationship(List<Relationship> relationship) {
        this.relationship = relationship;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public List<PersonContact> getPersonContact() {
        return personContact;
    }

    public void setPersonContact(List<PersonContact> personContact) {
        this.personContact = personContact;
    }

    public String getRaceOtherDescription() {
        return raceOtherDescription;
    }

    public void setRaceOtherDescription(String raceOtherDescription) {
        this.raceOtherDescription = raceOtherDescription;
    }

    public Integer getSubsidized() {
        return subsidized;
    }

    public void setSubsidized(Integer subsidized) {
        this.subsidized = subsidized;
    }

    public GroupMembership getGroupMembership() {
        return groupMembership;
    }

    public void setGroupMembership(GroupMembership groupMembership) {
        this.groupMembership = groupMembership;
    }

    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }

    public List<UserDefinedValue> getUserDefinedValue() {
        return userDefinedValue;
    }

    public void setUserDefinedValue(List<UserDefinedValue> userDefinedValue) {
        this.userDefinedValue = userDefinedValue;
    }

    public List<PersonPhone> getPersonPhone() {
        return personPhone;
    }

    public void setPersonPhone(List<PersonPhone> personPhone) {
        this.personPhone = personPhone;
    }

    public Integer getMailZip() {
        return mailZip;
    }

    public void setMailZip(Integer mailZip) {
        this.mailZip = mailZip;
    }

    public String getPhysicalAddress1() {
        return physicalAddress1;
    }

    public void setPhysicalAddress1(String physicalAddress1) {
        this.physicalAddress1 = physicalAddress1;
    }

    public String getPhysicalCounty() {
        return physicalCounty;
    }

    public void setPhysicalCounty(String physicalCounty) {
        this.physicalCounty = physicalCounty;
    }

    public String getMailState() {
        return mailState;
    }

    public void setMailState(String mailState) {
        this.mailState = mailState;
    }

    public String getMailCity() {
        return mailCity;
    }

    public void setMailCity(String mailCity) {
        this.mailCity = mailCity;
    }

    public String getPhysicalCity() {
        return physicalCity;
    }

    public void setPhysicalCity(String physicalCity) {
        this.physicalCity = physicalCity;
    }

    public Integer getPhysicalZip() {
        return physicalZip;
    }

    public void setPhysicalZip(Integer physicalZip) {
        this.physicalZip = physicalZip;
    }

    public String getPhysicalState() {
        return physicalState;
    }

    public void setPhysicalState(String physicalState) {
        this.physicalState = physicalState;
    }

    public String getMailAddress1() {
        return mailAddress1;
    }

    public void setMailAddress1(String mailAddress1) {
        this.mailAddress1 = mailAddress1;
    }

    public String getPreferredName() {
        return preferredName;
    }

    public void setPreferredName(String preferredName) {
        this.preferredName = preferredName;
    }

    public String getShareMailingAddressFamilyID() {
        return shareMailingAddressFamilyID;
    }

    public void setShareMailingAddressFamilyID(String shareMailingAddressFamilyID) {
        this.shareMailingAddressFamilyID = shareMailingAddressFamilyID;
    }

    public String getSharePhysicalAddressFamilyID() {
        return sharePhysicalAddressFamilyID;
    }

    public void setSharePhysicalAddressFamilyID(String sharePhysicalAddressFamilyID) {
        this.sharePhysicalAddressFamilyID = sharePhysicalAddressFamilyID;
    }

    public String getSchoolDistrictCodeID() {
        return schoolDistrictCodeID;
    }

    public void setSchoolDistrictCodeID(String schoolDistrictCodeID) {
        this.schoolDistrictCodeID = schoolDistrictCodeID;
    }

    public String getSchoolDistrict() {
        return schoolDistrict;
    }

    public void setSchoolDistrict(String schoolDistrict) {
        this.schoolDistrict = schoolDistrict;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getPhysicalAddress2() {
        return physicalAddress2;
    }

    public void setPhysicalAddress2(String physicalAddress2) {
        this.physicalAddress2 = physicalAddress2;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getAlternateID() {
        return alternateID;
    }

    public void setAlternateID(Integer alternateID) {
        this.alternateID = alternateID;
    }
    
}
