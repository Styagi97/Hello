/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Immunization {
      private List<ImmunizationDetail> immunizationDetail = new ArrayList<ImmunizationDetail>();
    private String responsibleStaffID;
    private Tuberculosis tuberculosis;
    private String personID;
    private String responsibleStaff;

    public List<ImmunizationDetail> getImmunizationDetail() {
        return immunizationDetail;
    }

    public void setImmunizationDetail(List<ImmunizationDetail> immunizationDetail) {
        this.immunizationDetail = immunizationDetail;
    }

    public String getResponsibleStaffID() {
        return responsibleStaffID;
    }

    public void setResponsibleStaffID(String responsibleStaffID) {
        this.responsibleStaffID = responsibleStaffID;
    }

    public Tuberculosis getTuberculosis() {
        return tuberculosis;
    }

    public void setTuberculosis(Tuberculosis tuberculosis) {
        this.tuberculosis = tuberculosis;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getResponsibleStaff() {
        return responsibleStaff;
    }

    public void setResponsibleStaff(String responsibleStaff) {
        this.responsibleStaff = responsibleStaff;
    }
    
}
