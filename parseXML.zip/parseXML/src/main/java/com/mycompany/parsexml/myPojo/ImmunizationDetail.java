/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class ImmunizationDetail {
      private String personID;
    private Integer exempt;
    private Integer due1;
    private Integer due2;
    private String name;
    private Integer due3;
    private Integer due4;
    private Integer due5;
    private String exemptReason;
    private String exemptReasonCodeID;

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public Integer getExempt() {
        return exempt;
    }

    public void setExempt(Integer exempt) {
        this.exempt = exempt;
    }

    public Integer getDue1() {
        return due1;
    }

    public void setDue1(Integer due1) {
        this.due1 = due1;
    }

    public Integer getDue2() {
        return due2;
    }

    public void setDue2(Integer due2) {
        this.due2 = due2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getDue3() {
        return due3;
    }

    public void setDue3(Integer due3) {
        this.due3 = due3;
    }

    public Integer getDue4() {
        return due4;
    }

    public void setDue4(Integer due4) {
        this.due4 = due4;
    }

    public Integer getDue5() {
        return due5;
    }

    public void setDue5(Integer due5) {
        this.due5 = due5;
    }

    public String getExemptReason() {
        return exemptReason;
    }

    public void setExemptReason(String exemptReason) {
        this.exemptReason = exemptReason;
    }

    public String getExemptReasonCodeID() {
        return exemptReasonCodeID;
    }

    public void setExemptReasonCodeID(String exemptReasonCodeID) {
        this.exemptReasonCodeID = exemptReasonCodeID;
    }
}
