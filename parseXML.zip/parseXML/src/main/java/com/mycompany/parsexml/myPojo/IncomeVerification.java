/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class IncomeVerification {
       private Integer annualAmount;
    private String earnerName;
    private Integer amountPerEarningPeriod;
    private String earnerID;
    private String familyID;
    private String note;
    private String descriptionCodeID;
    private String incomeVerificationTypeCodeID;
    private Integer earnerNumber;
    private String earningPeriodCodeID;

    public Integer getAnnualAmount() {
        return annualAmount;
    }

    public void setAnnualAmount(Integer annualAmount) {
        this.annualAmount = annualAmount;
    }

    public String getEarnerName() {
        return earnerName;
    }

    public void setEarnerName(String earnerName) {
        this.earnerName = earnerName;
    }

    public Integer getAmountPerEarningPeriod() {
        return amountPerEarningPeriod;
    }

    public void setAmountPerEarningPeriod(Integer amountPerEarningPeriod) {
        this.amountPerEarningPeriod = amountPerEarningPeriod;
    }

    public String getEarnerID() {
        return earnerID;
    }

    public void setEarnerID(String earnerID) {
        this.earnerID = earnerID;
    }

    public String getFamilyID() {
        return familyID;
    }

    public void setFamilyID(String familyID) {
        this.familyID = familyID;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getDescriptionCodeID() {
        return descriptionCodeID;
    }

    public void setDescriptionCodeID(String descriptionCodeID) {
        this.descriptionCodeID = descriptionCodeID;
    }

    public String getIncomeVerificationTypeCodeID() {
        return incomeVerificationTypeCodeID;
    }

    public void setIncomeVerificationTypeCodeID(String incomeVerificationTypeCodeID) {
        this.incomeVerificationTypeCodeID = incomeVerificationTypeCodeID;
    }

    public Integer getEarnerNumber() {
        return earnerNumber;
    }

    public void setEarnerNumber(Integer earnerNumber) {
        this.earnerNumber = earnerNumber;
    }

    public String getEarningPeriodCodeID() {
        return earningPeriodCodeID;
    }

    public void setEarningPeriodCodeID(String earningPeriodCodeID) {
        this.earningPeriodCodeID = earningPeriodCodeID;
    }
}
