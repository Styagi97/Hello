/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class LanguageProficiency {
      private String proficiency;
    private String languageCodeID;
    private String personID;
    private String language;
    private Integer isPrimary;
    private String proficiencyCodeID;

    public String getProficiency() {
        return proficiency;
    }

    public void setProficiency(String proficiency) {
        this.proficiency = proficiency;
    }

    public String getLanguageCodeID() {
        return languageCodeID;
    }

    public void setLanguageCodeID(String languageCodeID) {
        this.languageCodeID = languageCodeID;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Integer getIsPrimary() {
        return isPrimary;
    }

    public void setIsPrimary(Integer isPrimary) {
        this.isPrimary = isPrimary;
    }

    public String getProficiencyCodeID() {
        return proficiencyCodeID;
    }

    public void setProficiencyCodeID(String proficiencyCodeID) {
        this.proficiencyCodeID = proficiencyCodeID;
    }
}
