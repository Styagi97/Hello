/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Participants {
     private List<Participant> participant = new ArrayList<>();
    public List<Participant> getParticipant() {
        return participant;
    }
    public void setParticipant(List<Participant> participant) {
        this.participant = participant;
    }
}
