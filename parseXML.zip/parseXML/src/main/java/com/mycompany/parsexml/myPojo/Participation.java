/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class Participation {
       private ParticipationImmunization participationImmunization;
    private ParticipationFamilyServicesInformation participationFamilyServicesInformation;
    private String program;
    private String personID;
    private String programTerm;
    private String programTermID;
    private Enrollment enrollment;
    private String participationID;
    private String programID;

    public ParticipationImmunization getParticipationImmunization() {
        return participationImmunization;
    }

    public void setParticipationImmunization(ParticipationImmunization participationImmunization) {
        this.participationImmunization = participationImmunization;
    }

    public ParticipationFamilyServicesInformation getParticipationFamilyServicesInformation() {
        return participationFamilyServicesInformation;
    }

    public void setParticipationFamilyServicesInformation(ParticipationFamilyServicesInformation participationFamilyServicesInformation) {
        this.participationFamilyServicesInformation = participationFamilyServicesInformation;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getProgramTerm() {
        return programTerm;
    }

    public void setProgramTerm(String programTerm) {
        this.programTerm = programTerm;
    }

    public String getProgramTermID() {
        return programTermID;
    }

    public void setProgramTermID(String programTermID) {
        this.programTermID = programTermID;
    }

    public Enrollment getEnrollment() {
        return enrollment;
    }

    public void setEnrollment(Enrollment enrollment) {
        this.enrollment = enrollment;
    }

    public String getParticipationID() {
        return participationID;
    }

    public void setParticipationID(String participationID) {
        this.participationID = participationID;
    }

    public String getProgramID() {
        return programID;
    }

    public void setProgramID(String programID) {
        this.programID = programID;
    }
    
}
