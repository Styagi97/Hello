/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class ParticipationFamilyServicesInformation {
  private Integer wICServicesReceived;
    private String participationID;    

    public Integer getwICServicesReceived() {
        return wICServicesReceived;
    }

    public void setwICServicesReceived(Integer wICServicesReceived) {
        this.wICServicesReceived = wICServicesReceived;
    }

    public String getParticipationID() {
        return participationID;
    }

    public void setParticipationID(String participationID) {
        this.participationID = participationID;
    }
}
