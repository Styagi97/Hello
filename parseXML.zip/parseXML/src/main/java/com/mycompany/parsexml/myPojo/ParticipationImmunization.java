/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class ParticipationImmunization {
     private String statusAtStart;
    private String participationID;
    private String statusAtStartCodeID;
    private String statusCurrent;
    private String statusCurrentCodeID;

    public String getStatusAtStart() {
        return statusAtStart;
    }

    public void setStatusAtStart(String statusAtStart) {
        this.statusAtStart = statusAtStart;
    }

    public String getParticipationID() {
        return participationID;
    }

    public void setParticipationID(String participationID) {
        this.participationID = participationID;
    }

    public String getStatusAtStartCodeID() {
        return statusAtStartCodeID;
    }

    public void setStatusAtStartCodeID(String statusAtStartCodeID) {
        this.statusAtStartCodeID = statusAtStartCodeID;
    }

    public String getStatusCurrent() {
        return statusCurrent;
    }

    public void setStatusCurrent(String statusCurrent) {
        this.statusCurrent = statusCurrent;
    }

    public String getStatusCurrentCodeID() {
        return statusCurrentCodeID;
    }

    public void setStatusCurrentCodeID(String statusCurrentCodeID) {
        this.statusCurrentCodeID = statusCurrentCodeID;
    }
}
