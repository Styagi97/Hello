/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class PersonContact {
     private ContactPhone contactPhone;
    private Integer emergencyContact;
    private String relationToPersonCodeID;
    private String personID;
    private String relationToPerson;
    private Integer contactNumber;
    private Integer doNotReleaseTo;
    private String contactID;
    private Integer releaseTo;

    public ContactPhone getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(ContactPhone contactPhone) {
        this.contactPhone = contactPhone;
    }

    public Integer getEmergencyContact() {
        return emergencyContact;
    }

    public void setEmergencyContact(Integer emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public String getRelationToPersonCodeID() {
        return relationToPersonCodeID;
    }

    public void setRelationToPersonCodeID(String relationToPersonCodeID) {
        this.relationToPersonCodeID = relationToPersonCodeID;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getRelationToPerson() {
        return relationToPerson;
    }

    public void setRelationToPerson(String relationToPerson) {
        this.relationToPerson = relationToPerson;
    }

    public Integer getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(Integer contactNumber) {
        this.contactNumber = contactNumber;
    }

    public Integer getDoNotReleaseTo() {
        return doNotReleaseTo;
    }

    public void setDoNotReleaseTo(Integer doNotReleaseTo) {
        this.doNotReleaseTo = doNotReleaseTo;
    }

    public String getContactID() {
        return contactID;
    }

    public void setContactID(String contactID) {
        this.contactID = contactID;
    }

    public Integer getReleaseTo() {
        return releaseTo;
    }

    public void setReleaseTo(Integer releaseTo) {
        this.releaseTo = releaseTo;
    }
}
