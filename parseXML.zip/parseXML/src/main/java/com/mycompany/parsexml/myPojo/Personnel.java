/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Personnel {
      private List<Personnel1> personnel = new ArrayList<>(); 

    public List<Personnel1> getPersonnel() {
        return personnel;
    }

    public void setPersonnel(List<Personnel1> personnel) {
        this.personnel = personnel;
    }
}
