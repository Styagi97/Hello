/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Personnel1 {
      private String contactPhone2;
    private Integer pIRFCPSupervisor;
    private String parentTypeCodeID;
    private Integer isHispanic;
    private Integer cDAAppropriateOption;
    private PersonnelAgencyFunding personnelAgencyFunding;
    private Integer birthday;
    private Integer mailZip;
    private Integer newlyCreatedPosition;
    private String maritalStatusCodeID;
    private String educationEnrolledDegreeCodeID;
    private String mailState;
    private Integer pIRECDManagerCoordinator;
    private String personID;
    private String educationHighestDegree;
    private Integer currentPositionDate;
    private Integer pIRHomeVisitor;
    private Integer healthCredential;
    private String cDAEHSCodeID;
    private String parentType;
    private String nameSuffix;
    private Integer fCPGEDorHSOnly;
    private Boolean pIRFamilyChildCareSpecialist;
    private String educationLevelCodeID;
    private Integer physicalZip;
    private String educationEnrolledDegree;
    private String cDAEHS;
    private Integer eCEDegree;
    private String position;
    private String serviceAreaCodeID;
    private Integer pIRFCCTeacher;
    private Integer pIRTeacher;
    private String primaryAgencyID;
    private Integer pIRChildDevelopmentSupervisor;
    private String positionCodeID;
    private String maritalStatus;
    private Integer active;
    private String serviceArea;
    private Integer pIRHomeBasedSupervisor;
    private String fullOrPartTime;
    private String lastName;
    private String sexCodeID;
    private String contactRelationship;
    private Integer mailSameAsPhysical;
    private String educationDegreeCodeID;
    private Integer fCPDegree;
    private String primaryProgramID;
    private Integer worksDirectlyWithFamilies;
    private Integer followUpNeeded;
    private String educationDegree;
    private String sex;
    private List<PersonPhone> personPhone = new ArrayList<>();
    private String physicalAddress1;
    private Integer referencesVerified;
    private String physicalCounty;
    private String contactPhone;
    private LanguageProficiency languageProficiency;
    private String currentPosition;
    private Integer crimeCheckSignature;
    private String race;
    private String mailCity;
    private String cDAHS;
    private Integer socialServiceCredential;
    private String physicalCity;
    private String primarySiteID;
    private String raceCodeID;
    private String fullOrPartTimeCodeID;
    private String cDAHSCodeID;
    private String firstName;
    private Integer pIRAssistantTeacher;
    private Integer pIRFamilyWorker;
    private String primaryAgency;
    private String middleName;
    private String educationLevel;
    private String sSN;
    private Integer firstPositionDate;
    private Integer fCPProgram;
    private String physicalState;
    private String supervisorID;
    private String primarySite;
    private String cDAAdvisor;
    private String contactName;
    private String mailAddress1;
    private String permanentOrTemporaryCodeID;
    private String mailDestinationCodeID;
    private String firstPosition;
    private String permanentOrTemporary;
    private String fCPDegreeCodeID;
    private Integer tBTestDue;
    private String mailDestination;
    private String tBTestResult;
    private Integer lastPhysical;
    private String tBTestResultCodeID;
    private String primaryProgramOptionID;
    private String fCPDegreeName;
    private Integer crimeCheck;
    private Integer nextPhysical;
    private Integer crimeCheckDate;
    private Integer nextTBTestDue;
    private Integer column1;
    private Integer rehireDate;
    private String physicalAddress2;
    private UserDefinedValue userDefinedValue;
    private Integer cDAObtained;
    private Integer followUpDate;
    private String wageFrequencyCodeID;
    private String wageClassCodeID;
    private Integer hourlyRate;
    private String wageClass;
    private String wageFrequency;
    private Integer positionCreatedDate;
    private Integer terminationDate;
    private String termination;
    private String terminationCodeID;
    private String contactExt2;
    private String contactExt;
    private Integer lastReviewDate;
    private String lastReviewStatus;
    private String lastReviewStatusCodeID;
    private Integer nextReviewDate;
    private String cDANotes;
    private Integer probationEndingDate;
    private String rehireTitle;
    private String cDAAdvisor1;
    private Integer daysInactive;
    private Integer hourlyIncreaseDate;
    private Integer hourlyIncrease;
    private String educationNotes;

    public String getContactPhone2() {
        return contactPhone2;
    }

    public void setContactPhone2(String contactPhone2) {
        this.contactPhone2 = contactPhone2;
    }

    public Integer getpIRFCPSupervisor() {
        return pIRFCPSupervisor;
    }

    public void setpIRFCPSupervisor(Integer pIRFCPSupervisor) {
        this.pIRFCPSupervisor = pIRFCPSupervisor;
    }

    public String getParentTypeCodeID() {
        return parentTypeCodeID;
    }

    public void setParentTypeCodeID(String parentTypeCodeID) {
        this.parentTypeCodeID = parentTypeCodeID;
    }

    public Integer getIsHispanic() {
        return isHispanic;
    }

    public void setIsHispanic(Integer isHispanic) {
        this.isHispanic = isHispanic;
    }

    public Integer getcDAAppropriateOption() {
        return cDAAppropriateOption;
    }

    public void setcDAAppropriateOption(Integer cDAAppropriateOption) {
        this.cDAAppropriateOption = cDAAppropriateOption;
    }

    public PersonnelAgencyFunding getPersonnelAgencyFunding() {
        return personnelAgencyFunding;
    }

    public void setPersonnelAgencyFunding(PersonnelAgencyFunding personnelAgencyFunding) {
        this.personnelAgencyFunding = personnelAgencyFunding;
    }

    public Integer getBirthday() {
        return birthday;
    }

    public void setBirthday(Integer birthday) {
        this.birthday = birthday;
    }

    public Integer getMailZip() {
        return mailZip;
    }

    public void setMailZip(Integer mailZip) {
        this.mailZip = mailZip;
    }

    public Integer getNewlyCreatedPosition() {
        return newlyCreatedPosition;
    }

    public void setNewlyCreatedPosition(Integer newlyCreatedPosition) {
        this.newlyCreatedPosition = newlyCreatedPosition;
    }

    public String getMaritalStatusCodeID() {
        return maritalStatusCodeID;
    }

    public void setMaritalStatusCodeID(String maritalStatusCodeID) {
        this.maritalStatusCodeID = maritalStatusCodeID;
    }

    public String getEducationEnrolledDegreeCodeID() {
        return educationEnrolledDegreeCodeID;
    }

    public void setEducationEnrolledDegreeCodeID(String educationEnrolledDegreeCodeID) {
        this.educationEnrolledDegreeCodeID = educationEnrolledDegreeCodeID;
    }

    public String getMailState() {
        return mailState;
    }

    public void setMailState(String mailState) {
        this.mailState = mailState;
    }

    public Integer getpIRECDManagerCoordinator() {
        return pIRECDManagerCoordinator;
    }

    public void setpIRECDManagerCoordinator(Integer pIRECDManagerCoordinator) {
        this.pIRECDManagerCoordinator = pIRECDManagerCoordinator;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getEducationHighestDegree() {
        return educationHighestDegree;
    }

    public void setEducationHighestDegree(String educationHighestDegree) {
        this.educationHighestDegree = educationHighestDegree;
    }

    public Integer getCurrentPositionDate() {
        return currentPositionDate;
    }

    public void setCurrentPositionDate(Integer currentPositionDate) {
        this.currentPositionDate = currentPositionDate;
    }

    public Integer getpIRHomeVisitor() {
        return pIRHomeVisitor;
    }

    public void setpIRHomeVisitor(Integer pIRHomeVisitor) {
        this.pIRHomeVisitor = pIRHomeVisitor;
    }

    public Integer getHealthCredential() {
        return healthCredential;
    }

    public void setHealthCredential(Integer healthCredential) {
        this.healthCredential = healthCredential;
    }

    public String getcDAEHSCodeID() {
        return cDAEHSCodeID;
    }

    public void setcDAEHSCodeID(String cDAEHSCodeID) {
        this.cDAEHSCodeID = cDAEHSCodeID;
    }

    public String getParentType() {
        return parentType;
    }

    public void setParentType(String parentType) {
        this.parentType = parentType;
    }

    public String getNameSuffix() {
        return nameSuffix;
    }

    public void setNameSuffix(String nameSuffix) {
        this.nameSuffix = nameSuffix;
    }

    public Integer getfCPGEDorHSOnly() {
        return fCPGEDorHSOnly;
    }

    public void setfCPGEDorHSOnly(Integer fCPGEDorHSOnly) {
        this.fCPGEDorHSOnly = fCPGEDorHSOnly;
    }

    public Boolean getpIRFamilyChildCareSpecialist() {
        return pIRFamilyChildCareSpecialist;
    }

    public void setpIRFamilyChildCareSpecialist(Boolean pIRFamilyChildCareSpecialist) {
        this.pIRFamilyChildCareSpecialist = pIRFamilyChildCareSpecialist;
    }

    public String getEducationLevelCodeID() {
        return educationLevelCodeID;
    }

    public void setEducationLevelCodeID(String educationLevelCodeID) {
        this.educationLevelCodeID = educationLevelCodeID;
    }

    public Integer getPhysicalZip() {
        return physicalZip;
    }

    public void setPhysicalZip(Integer physicalZip) {
        this.physicalZip = physicalZip;
    }

    public String getEducationEnrolledDegree() {
        return educationEnrolledDegree;
    }

    public void setEducationEnrolledDegree(String educationEnrolledDegree) {
        this.educationEnrolledDegree = educationEnrolledDegree;
    }

    public String getcDAEHS() {
        return cDAEHS;
    }

    public void setcDAEHS(String cDAEHS) {
        this.cDAEHS = cDAEHS;
    }

    public Integer geteCEDegree() {
        return eCEDegree;
    }

    public void seteCEDegree(Integer eCEDegree) {
        this.eCEDegree = eCEDegree;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getServiceAreaCodeID() {
        return serviceAreaCodeID;
    }

    public void setServiceAreaCodeID(String serviceAreaCodeID) {
        this.serviceAreaCodeID = serviceAreaCodeID;
    }

    public Integer getpIRFCCTeacher() {
        return pIRFCCTeacher;
    }

    public void setpIRFCCTeacher(Integer pIRFCCTeacher) {
        this.pIRFCCTeacher = pIRFCCTeacher;
    }

    public Integer getpIRTeacher() {
        return pIRTeacher;
    }

    public void setpIRTeacher(Integer pIRTeacher) {
        this.pIRTeacher = pIRTeacher;
    }

    public String getPrimaryAgencyID() {
        return primaryAgencyID;
    }

    public void setPrimaryAgencyID(String primaryAgencyID) {
        this.primaryAgencyID = primaryAgencyID;
    }

    public Integer getpIRChildDevelopmentSupervisor() {
        return pIRChildDevelopmentSupervisor;
    }

    public void setpIRChildDevelopmentSupervisor(Integer pIRChildDevelopmentSupervisor) {
        this.pIRChildDevelopmentSupervisor = pIRChildDevelopmentSupervisor;
    }

    public String getPositionCodeID() {
        return positionCodeID;
    }

    public void setPositionCodeID(String positionCodeID) {
        this.positionCodeID = positionCodeID;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    public String getServiceArea() {
        return serviceArea;
    }

    public void setServiceArea(String serviceArea) {
        this.serviceArea = serviceArea;
    }

    public Integer getpIRHomeBasedSupervisor() {
        return pIRHomeBasedSupervisor;
    }

    public void setpIRHomeBasedSupervisor(Integer pIRHomeBasedSupervisor) {
        this.pIRHomeBasedSupervisor = pIRHomeBasedSupervisor;
    }

    public String getFullOrPartTime() {
        return fullOrPartTime;
    }

    public void setFullOrPartTime(String fullOrPartTime) {
        this.fullOrPartTime = fullOrPartTime;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSexCodeID() {
        return sexCodeID;
    }

    public void setSexCodeID(String sexCodeID) {
        this.sexCodeID = sexCodeID;
    }

    public String getContactRelationship() {
        return contactRelationship;
    }

    public void setContactRelationship(String contactRelationship) {
        this.contactRelationship = contactRelationship;
    }

    public Integer getMailSameAsPhysical() {
        return mailSameAsPhysical;
    }

    public void setMailSameAsPhysical(Integer mailSameAsPhysical) {
        this.mailSameAsPhysical = mailSameAsPhysical;
    }

    public String getEducationDegreeCodeID() {
        return educationDegreeCodeID;
    }

    public void setEducationDegreeCodeID(String educationDegreeCodeID) {
        this.educationDegreeCodeID = educationDegreeCodeID;
    }

    public Integer getfCPDegree() {
        return fCPDegree;
    }

    public void setfCPDegree(Integer fCPDegree) {
        this.fCPDegree = fCPDegree;
    }

    public String getPrimaryProgramID() {
        return primaryProgramID;
    }

    public void setPrimaryProgramID(String primaryProgramID) {
        this.primaryProgramID = primaryProgramID;
    }

    public Integer getWorksDirectlyWithFamilies() {
        return worksDirectlyWithFamilies;
    }

    public void setWorksDirectlyWithFamilies(Integer worksDirectlyWithFamilies) {
        this.worksDirectlyWithFamilies = worksDirectlyWithFamilies;
    }

    public Integer getFollowUpNeeded() {
        return followUpNeeded;
    }

    public void setFollowUpNeeded(Integer followUpNeeded) {
        this.followUpNeeded = followUpNeeded;
    }

    public String getEducationDegree() {
        return educationDegree;
    }

    public void setEducationDegree(String educationDegree) {
        this.educationDegree = educationDegree;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public List<PersonPhone> getPersonPhone() {
        return personPhone;
    }

    public void setPersonPhone(List<PersonPhone> personPhone) {
        this.personPhone = personPhone;
    }
    
    public String getPhysicalAddress1() {
        return physicalAddress1;
    }

    public void setPhysicalAddress1(String physicalAddress1) {
        this.physicalAddress1 = physicalAddress1;
    }

    public Integer getReferencesVerified() {
        return referencesVerified;
    }

    public void setReferencesVerified(Integer referencesVerified) {
        this.referencesVerified = referencesVerified;
    }

    public String getPhysicalCounty() {
        return physicalCounty;
    }

    public void setPhysicalCounty(String physicalCounty) {
        this.physicalCounty = physicalCounty;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public LanguageProficiency getLanguageProficiency() {
        return languageProficiency;
    }

    public void setLanguageProficiency(LanguageProficiency languageProficiency) {
        this.languageProficiency = languageProficiency;
    }

    public String getCurrentPosition() {
        return currentPosition;
    }

    public void setCurrentPosition(String currentPosition) {
        this.currentPosition = currentPosition;
    }

    public Integer getCrimeCheckSignature() {
        return crimeCheckSignature;
    }

    public void setCrimeCheckSignature(Integer crimeCheckSignature) {
        this.crimeCheckSignature = crimeCheckSignature;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public String getMailCity() {
        return mailCity;
    }

    public void setMailCity(String mailCity) {
        this.mailCity = mailCity;
    }

    public String getcDAHS() {
        return cDAHS;
    }

    public void setcDAHS(String cDAHS) {
        this.cDAHS = cDAHS;
    }

    public Integer getSocialServiceCredential() {
        return socialServiceCredential;
    }

    public void setSocialServiceCredential(Integer socialServiceCredential) {
        this.socialServiceCredential = socialServiceCredential;
    }

    public String getPhysicalCity() {
        return physicalCity;
    }

    public void setPhysicalCity(String physicalCity) {
        this.physicalCity = physicalCity;
    }

    public String getPrimarySiteID() {
        return primarySiteID;
    }

    public void setPrimarySiteID(String primarySiteID) {
        this.primarySiteID = primarySiteID;
    }

    public String getRaceCodeID() {
        return raceCodeID;
    }

    public void setRaceCodeID(String raceCodeID) {
        this.raceCodeID = raceCodeID;
    }

    public String getFullOrPartTimeCodeID() {
        return fullOrPartTimeCodeID;
    }

    public void setFullOrPartTimeCodeID(String fullOrPartTimeCodeID) {
        this.fullOrPartTimeCodeID = fullOrPartTimeCodeID;
    }

    public String getcDAHSCodeID() {
        return cDAHSCodeID;
    }

    public void setcDAHSCodeID(String cDAHSCodeID) {
        this.cDAHSCodeID = cDAHSCodeID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Integer getpIRAssistantTeacher() {
        return pIRAssistantTeacher;
    }

    public void setpIRAssistantTeacher(Integer pIRAssistantTeacher) {
        this.pIRAssistantTeacher = pIRAssistantTeacher;
    }

    public Integer getpIRFamilyWorker() {
        return pIRFamilyWorker;
    }

    public void setpIRFamilyWorker(Integer pIRFamilyWorker) {
        this.pIRFamilyWorker = pIRFamilyWorker;
    }

    public String getPrimaryAgency() {
        return primaryAgency;
    }

    public void setPrimaryAgency(String primaryAgency) {
        this.primaryAgency = primaryAgency;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getEducationLevel() {
        return educationLevel;
    }

    public void setEducationLevel(String educationLevel) {
        this.educationLevel = educationLevel;
    }

    public String getsSN() {
        return sSN;
    }

    public void setsSN(String sSN) {
        this.sSN = sSN;
    }

    public Integer getFirstPositionDate() {
        return firstPositionDate;
    }

    public void setFirstPositionDate(Integer firstPositionDate) {
        this.firstPositionDate = firstPositionDate;
    }

    public Integer getfCPProgram() {
        return fCPProgram;
    }

    public void setfCPProgram(Integer fCPProgram) {
        this.fCPProgram = fCPProgram;
    }

    public String getPhysicalState() {
        return physicalState;
    }

    public void setPhysicalState(String physicalState) {
        this.physicalState = physicalState;
    }

    public String getSupervisorID() {
        return supervisorID;
    }

    public void setSupervisorID(String supervisorID) {
        this.supervisorID = supervisorID;
    }

    public String getPrimarySite() {
        return primarySite;
    }

    public void setPrimarySite(String primarySite) {
        this.primarySite = primarySite;
    }

    public String getcDAAdvisor() {
        return cDAAdvisor;
    }

    public void setcDAAdvisor(String cDAAdvisor) {
        this.cDAAdvisor = cDAAdvisor;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getMailAddress1() {
        return mailAddress1;
    }

    public void setMailAddress1(String mailAddress1) {
        this.mailAddress1 = mailAddress1;
    }

    public String getPermanentOrTemporaryCodeID() {
        return permanentOrTemporaryCodeID;
    }

    public void setPermanentOrTemporaryCodeID(String permanentOrTemporaryCodeID) {
        this.permanentOrTemporaryCodeID = permanentOrTemporaryCodeID;
    }

    public String getMailDestinationCodeID() {
        return mailDestinationCodeID;
    }

    public void setMailDestinationCodeID(String mailDestinationCodeID) {
        this.mailDestinationCodeID = mailDestinationCodeID;
    }

    public String getFirstPosition() {
        return firstPosition;
    }

    public void setFirstPosition(String firstPosition) {
        this.firstPosition = firstPosition;
    }

    public String getPermanentOrTemporary() {
        return permanentOrTemporary;
    }

    public void setPermanentOrTemporary(String permanentOrTemporary) {
        this.permanentOrTemporary = permanentOrTemporary;
    }

    public String getfCPDegreeCodeID() {
        return fCPDegreeCodeID;
    }

    public void setfCPDegreeCodeID(String fCPDegreeCodeID) {
        this.fCPDegreeCodeID = fCPDegreeCodeID;
    }

    public Integer gettBTestDue() {
        return tBTestDue;
    }

    public void settBTestDue(Integer tBTestDue) {
        this.tBTestDue = tBTestDue;
    }

    public String getMailDestination() {
        return mailDestination;
    }

    public void setMailDestination(String mailDestination) {
        this.mailDestination = mailDestination;
    }

    public String gettBTestResult() {
        return tBTestResult;
    }

    public void settBTestResult(String tBTestResult) {
        this.tBTestResult = tBTestResult;
    }

    public Integer getLastPhysical() {
        return lastPhysical;
    }

    public void setLastPhysical(Integer lastPhysical) {
        this.lastPhysical = lastPhysical;
    }

    public String gettBTestResultCodeID() {
        return tBTestResultCodeID;
    }

    public void settBTestResultCodeID(String tBTestResultCodeID) {
        this.tBTestResultCodeID = tBTestResultCodeID;
    }

    public String getPrimaryProgramOptionID() {
        return primaryProgramOptionID;
    }

    public void setPrimaryProgramOptionID(String primaryProgramOptionID) {
        this.primaryProgramOptionID = primaryProgramOptionID;
    }

    public String getfCPDegreeName() {
        return fCPDegreeName;
    }

    public void setfCPDegreeName(String fCPDegreeName) {
        this.fCPDegreeName = fCPDegreeName;
    }

    public Integer getCrimeCheck() {
        return crimeCheck;
    }

    public void setCrimeCheck(Integer crimeCheck) {
        this.crimeCheck = crimeCheck;
    }

    public Integer getNextPhysical() {
        return nextPhysical;
    }

    public void setNextPhysical(Integer nextPhysical) {
        this.nextPhysical = nextPhysical;
    }

    public Integer getCrimeCheckDate() {
        return crimeCheckDate;
    }

    public void setCrimeCheckDate(Integer crimeCheckDate) {
        this.crimeCheckDate = crimeCheckDate;
    }

    public Integer getNextTBTestDue() {
        return nextTBTestDue;
    }

    public void setNextTBTestDue(Integer nextTBTestDue) {
        this.nextTBTestDue = nextTBTestDue;
    }

    public Integer getColumn1() {
        return column1;
    }

    public void setColumn1(Integer column1) {
        this.column1 = column1;
    }

    public Integer getRehireDate() {
        return rehireDate;
    }

    public void setRehireDate(Integer rehireDate) {
        this.rehireDate = rehireDate;
    }

    public String getPhysicalAddress2() {
        return physicalAddress2;
    }

    public void setPhysicalAddress2(String physicalAddress2) {
        this.physicalAddress2 = physicalAddress2;
    }

    public UserDefinedValue getUserDefinedValue() {
        return userDefinedValue;
    }

    public void setUserDefinedValue(UserDefinedValue userDefinedValue) {
        this.userDefinedValue = userDefinedValue;
    }

    public Integer getcDAObtained() {
        return cDAObtained;
    }

    public void setcDAObtained(Integer cDAObtained) {
        this.cDAObtained = cDAObtained;
    }

    public Integer getFollowUpDate() {
        return followUpDate;
    }

    public void setFollowUpDate(Integer followUpDate) {
        this.followUpDate = followUpDate;
    }

    public String getWageFrequencyCodeID() {
        return wageFrequencyCodeID;
    }

    public void setWageFrequencyCodeID(String wageFrequencyCodeID) {
        this.wageFrequencyCodeID = wageFrequencyCodeID;
    }

    public String getWageClassCodeID() {
        return wageClassCodeID;
    }

    public void setWageClassCodeID(String wageClassCodeID) {
        this.wageClassCodeID = wageClassCodeID;
    }

    public Integer getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(Integer hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public String getWageClass() {
        return wageClass;
    }

    public void setWageClass(String wageClass) {
        this.wageClass = wageClass;
    }

    public String getWageFrequency() {
        return wageFrequency;
    }

    public void setWageFrequency(String wageFrequency) {
        this.wageFrequency = wageFrequency;
    }

    public Integer getPositionCreatedDate() {
        return positionCreatedDate;
    }

    public void setPositionCreatedDate(Integer positionCreatedDate) {
        this.positionCreatedDate = positionCreatedDate;
    }

    public Integer getTerminationDate() {
        return terminationDate;
    }

    public void setTerminationDate(Integer terminationDate) {
        this.terminationDate = terminationDate;
    }

    public String getTermination() {
        return termination;
    }

    public void setTermination(String termination) {
        this.termination = termination;
    }

    public String getTerminationCodeID() {
        return terminationCodeID;
    }

    public void setTerminationCodeID(String terminationCodeID) {
        this.terminationCodeID = terminationCodeID;
    }

    public String getContactExt2() {
        return contactExt2;
    }

    public void setContactExt2(String contactExt2) {
        this.contactExt2 = contactExt2;
    }

    public String getContactExt() {
        return contactExt;
    }

    public void setContactExt(String contactExt) {
        this.contactExt = contactExt;
    }

    public Integer getLastReviewDate() {
        return lastReviewDate;
    }

    public void setLastReviewDate(Integer lastReviewDate) {
        this.lastReviewDate = lastReviewDate;
    }

    public String getLastReviewStatus() {
        return lastReviewStatus;
    }

    public void setLastReviewStatus(String lastReviewStatus) {
        this.lastReviewStatus = lastReviewStatus;
    }

    public String getLastReviewStatusCodeID() {
        return lastReviewStatusCodeID;
    }

    public void setLastReviewStatusCodeID(String lastReviewStatusCodeID) {
        this.lastReviewStatusCodeID = lastReviewStatusCodeID;
    }

    public Integer getNextReviewDate() {
        return nextReviewDate;
    }

    public void setNextReviewDate(Integer nextReviewDate) {
        this.nextReviewDate = nextReviewDate;
    }

    public String getcDANotes() {
        return cDANotes;
    }

    public void setcDANotes(String cDANotes) {
        this.cDANotes = cDANotes;
    }

    public Integer getProbationEndingDate() {
        return probationEndingDate;
    }

    public void setProbationEndingDate(Integer probationEndingDate) {
        this.probationEndingDate = probationEndingDate;
    }

    public String getRehireTitle() {
        return rehireTitle;
    }

    public void setRehireTitle(String rehireTitle) {
        this.rehireTitle = rehireTitle;
    }

    public String getcDAAdvisor1() {
        return cDAAdvisor1;
    }

    public void setcDAAdvisor1(String cDAAdvisor1) {
        this.cDAAdvisor1 = cDAAdvisor1;
    }

    public Integer getDaysInactive() {
        return daysInactive;
    }

    public void setDaysInactive(Integer daysInactive) {
        this.daysInactive = daysInactive;
    }

    public Integer getHourlyIncreaseDate() {
        return hourlyIncreaseDate;
    }

    public void setHourlyIncreaseDate(Integer hourlyIncreaseDate) {
        this.hourlyIncreaseDate = hourlyIncreaseDate;
    }

    public Integer getHourlyIncrease() {
        return hourlyIncrease;
    }

    public void setHourlyIncrease(Integer hourlyIncrease) {
        this.hourlyIncrease = hourlyIncrease;
    }

    public String getEducationNotes() {
        return educationNotes;
    }

    public void setEducationNotes(String educationNotes) {
        this.educationNotes = educationNotes;
    }
}
