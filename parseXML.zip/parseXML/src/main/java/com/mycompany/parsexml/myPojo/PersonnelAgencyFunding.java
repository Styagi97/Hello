/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class PersonnelAgencyFunding {
       private String personnelID;
    private Integer primaryFunding;
    private String costCenter;
    private Integer percentage;
    private String agencyFunding;
    private String personnelAgencyFundingID;
    private String agencyFundingID;

    public String getPersonnelID() {
        return personnelID;
    }

    public void setPersonnelID(String personnelID) {
        this.personnelID = personnelID;
    }

    public Integer getPrimaryFunding() {
        return primaryFunding;
    }

    public void setPrimaryFunding(Integer primaryFunding) {
        this.primaryFunding = primaryFunding;
    }

    public String getCostCenter() {
        return costCenter;
    }

    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    public Integer getPercentage() {
        return percentage;
    }

    public void setPercentage(Integer percentage) {
        this.percentage = percentage;
    }

    public String getAgencyFunding() {
        return agencyFunding;
    }

    public void setAgencyFunding(String agencyFunding) {
        this.agencyFunding = agencyFunding;
    }

    public String getPersonnelAgencyFundingID() {
        return personnelAgencyFundingID;
    }

    public void setPersonnelAgencyFundingID(String personnelAgencyFundingID) {
        this.personnelAgencyFundingID = personnelAgencyFundingID;
    }

    public String getAgencyFundingID() {
        return agencyFundingID;
    }

    public void setAgencyFundingID(String agencyFundingID) {
        this.agencyFundingID = agencyFundingID;
    }
}
