/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class Relationship {
       private String childPersonID;
    private String adultName;
    private String relationToChild;
    private Integer hasCustody;
    private String adultPersonID;
    private String relationToChildCodeID;

    public String getChildPersonID() {
        return childPersonID;
    }

    public void setChildPersonID(String childPersonID) {
        this.childPersonID = childPersonID;
    }

    public String getAdultName() {
        return adultName;
    }

    public void setAdultName(String adultName) {
        this.adultName = adultName;
    }

    public String getRelationToChild() {
        return relationToChild;
    }

    public void setRelationToChild(String relationToChild) {
        this.relationToChild = relationToChild;
    }

    public Integer getHasCustody() {
        return hasCustody;
    }

    public void setHasCustody(Integer hasCustody) {
        this.hasCustody = hasCustody;
    }

    public String getAdultPersonID() {
        return adultPersonID;
    }

    public void setAdultPersonID(String adultPersonID) {
        this.adultPersonID = adultPersonID;
    }

    public String getRelationToChildCodeID() {
        return relationToChildCodeID;
    }

    public void setRelationToChildCodeID(String relationToChildCodeID) {
        this.relationToChildCodeID = relationToChildCodeID;
    }
}
