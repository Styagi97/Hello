/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Site {
     private Integer zip;
    private Integer totalStaff;
    private String siteID;
    private Integer totalAssistants;
    private String agencyID;
    private Integer licenseExpirationDate;
    private String address;
    private Integer licenseMaximumCapacity;
    private String primaryPhone;
    private String shortName;
    private String city;
    private Integer contractSite;
    private String county;
    private String name;
    private Integer totalTeachers;
    private Integer active;
    private String state;
    private List<Classroom> classroom = new ArrayList<>();
    private String region;
    private Integer federalInterestEstablished;
    private String fax;
    private List<SiteInspection> siteInspection = new ArrayList<>();
    private String responsibleStaff;
    private String staffPosition;
    private String licenseNumber;
    private String regionID;
    private String primaryPhoneExt;

    public Integer getZip() {
        return zip;
    }

    public void setZip(Integer zip) {
        this.zip = zip;
    }

    public Integer getTotalStaff() {
        return totalStaff;
    }

    public void setTotalStaff(Integer totalStaff) {
        this.totalStaff = totalStaff;
    }

    public String getSiteID() {
        return siteID;
    }

    public void setSiteID(String siteID) {
        this.siteID = siteID;
    }

    public Integer getTotalAssistants() {
        return totalAssistants;
    }

    public void setTotalAssistants(Integer totalAssistants) {
        this.totalAssistants = totalAssistants;
    }

    public String getAgencyID() {
        return agencyID;
    }

    public void setAgencyID(String agencyID) {
        this.agencyID = agencyID;
    }

    public Integer getLicenseExpirationDate() {
        return licenseExpirationDate;
    }

    public void setLicenseExpirationDate(Integer licenseExpirationDate) {
        this.licenseExpirationDate = licenseExpirationDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getLicenseMaximumCapacity() {
        return licenseMaximumCapacity;
    }

    public void setLicenseMaximumCapacity(Integer licenseMaximumCapacity) {
        this.licenseMaximumCapacity = licenseMaximumCapacity;
    }

    public String getPrimaryPhone() {
        return primaryPhone;
    }

    public void setPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Integer getContractSite() {
        return contractSite;
    }

    public void setContractSite(Integer contractSite) {
        this.contractSite = contractSite;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getTotalTeachers() {
        return totalTeachers;
    }

    public void setTotalTeachers(Integer totalTeachers) {
        this.totalTeachers = totalTeachers;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public List<Classroom> getClassroom() {
        return classroom;
    }

    public void setClassroom(List<Classroom> classroom) {
        this.classroom = classroom;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public Integer getFederalInterestEstablished() {
        return federalInterestEstablished;
    }

    public void setFederalInterestEstablished(Integer federalInterestEstablished) {
        this.federalInterestEstablished = federalInterestEstablished;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public List<SiteInspection> getSiteInspection() {
        return siteInspection;
    }

    public void setSiteInspection(List<SiteInspection> siteInspection) {
        this.siteInspection = siteInspection;
    }

    public String getResponsibleStaff() {
        return responsibleStaff;
    }

    public void setResponsibleStaff(String responsibleStaff) {
        this.responsibleStaff = responsibleStaff;
    }

    public String getStaffPosition() {
        return staffPosition;
    }

    public void setStaffPosition(String staffPosition) {
        this.staffPosition = staffPosition;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public String getRegionID() {
        return regionID;
    }

    public void setRegionID(String regionID) {
        this.regionID = regionID;
    }

    public String getPrimaryPhoneExt() {
        return primaryPhoneExt;
    }

    public void setPrimaryPhoneExt(String primaryPhoneExt) {
        this.primaryPhoneExt = primaryPhoneExt;
    }
    
}
