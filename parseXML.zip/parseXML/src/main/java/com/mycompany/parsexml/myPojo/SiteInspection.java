/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class SiteInspection {
       private String siteID;
    private Integer lastInspection;
    private String inspectionID;
    private String inspectionComments;
    private Integer nextInspection;
    private String name;

    public String getSiteID() {
        return siteID;
    }

    public void setSiteID(String siteID) {
        this.siteID = siteID;
    }

    public Integer getLastInspection() {
        return lastInspection;
    }

    public void setLastInspection(Integer lastInspection) {
        this.lastInspection = lastInspection;
    }

    public String getInspectionID() {
        return inspectionID;
    }

    public void setInspectionID(String inspectionID) {
        this.inspectionID = inspectionID;
    }

    public String getInspectionComments() {
        return inspectionComments;
    }

    public void setInspectionComments(String inspectionComments) {
        this.inspectionComments = inspectionComments;
    }

    public Integer getNextInspection() {
        return nextInspection;
    }

    public void setNextInspection(Integer nextInspection) {
        this.nextInspection = nextInspection;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
