/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class Tuberculosis {
     private TuberculosisSkinTest tuberculosisSkinTest;
    private String personID;

    public TuberculosisSkinTest getTuberculosisSkinTest() {
        return tuberculosisSkinTest;
    }

    public void setTuberculosisSkinTest(TuberculosisSkinTest tuberculosisSkinTest) {
        this.tuberculosisSkinTest = tuberculosisSkinTest;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }
}
