/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

/**
 *
 * @author admin
 */
public class TuberculosisSkinTest {
      private Integer dateRead;
    private String type;
    private String mmIndur;
    private String personID;
    private String typeCodeID;
    private Integer dateGiven;
    private Integer index;

    public Integer getDateRead() {
        return dateRead;
    }

    public void setDateRead(Integer dateRead) {
        this.dateRead = dateRead;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMmIndur() {
        return mmIndur;
    }

    public void setMmIndur(String mmIndur) {
        this.mmIndur = mmIndur;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getTypeCodeID() {
        return typeCodeID;
    }

    public void setTypeCodeID(String typeCodeID) {
        this.typeCodeID = typeCodeID;
    }

    public Integer getDateGiven() {
        return dateGiven;
    }

    public void setDateGiven(Integer dateGiven) {
        this.dateGiven = dateGiven;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }
}
