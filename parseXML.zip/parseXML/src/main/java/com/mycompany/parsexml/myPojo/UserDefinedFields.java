/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml.myPojo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class UserDefinedFields {
      private List<UserDefinedField> userDefinedField = new ArrayList<>();

    public List<UserDefinedField> getUserDefinedField() {
        return userDefinedField;
    }

    public void setUserDefinedField(List<UserDefinedField> userDefinedField) {
        this.userDefinedField = userDefinedField;
    }
      
}
