package com.mycompany.parsexml;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
public class newXML {

    public static void main(String[] args) throws IOException {
        JsonParser jp = new JsonParser();
        Gson json = new Gson();
        Reader reader = Files.newBufferedReader(Paths.get("C:\\Users\\admin\\Documents\\Shivani\\SampleJSON.json"));
        Map<String, Object> mp = json.fromJson(reader, HashMap.class);
//          System.out.println(mp);
        Map<String, Object> m1 = (Map) mp.get("ChildPlusDataExport");
        Map<String, Object> m3 = (Map) m1.get("Codes");
        List<Map<String, Object>> m4 = (List<Map<String, Object>>) m3.get("CodeType");
        m4.stream().forEach(i -> {
            System.out.println(i.get("Code"));
        });

    }
}
