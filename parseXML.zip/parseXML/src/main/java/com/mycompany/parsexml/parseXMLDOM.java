/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author admin
 */
public class parseXMLDOM {

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {

        try {
            File inputFile = new File("C:\\Users\\admin\\Documents\\Shivani\\sample.txt");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            NodeList nList = doc.getElementsByTagName("ChildPlusDataExport");
            System.out.println(nList.getLength());
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    System.out.println("PublicDatabaseID : " + eElement.getAttribute("PublicDatabaseID"));
                    System.out.println("ChildPlusVersion : " + eElement.getAttribute("ChildPlusVersion"));
                    System.out.println("AgencyName : " + eElement.getAttribute("AgencyName"));
                    NodeList CodeTypeList = eElement.getElementsByTagName("CodeType");
                    System.out.println(CodeTypeList.getLength());
                    for (int i = 0; i < CodeTypeList.getLength(); i++) {
                        Node item = (Node) CodeTypeList.item(i);
                        if (item.getNodeType() == Node.ELEMENT_NODE) {
                            Element eElement1 = (Element) item;
                            System.out.println("CodeType:" + eElement1.getAttribute("CodeType"));
                            System.out.println("Description :" + eElement1.getElementsByTagName("Description").item(i).getTextContent());
                            System.out.println("UserMaintainable :" + eElement1.getElementsByTagName("UserMaintainable").item(i).getTextContent());
                            NodeList CodeList = eElement.getElementsByTagName("Code");
                            System.out.println(CodeList.getLength());
                            for (int j = 0; j < CodeList.getLength(); j++) {
                                Node item1 = CodeList.item(j);
                                
                                if (item1.getNodeType() == Node.ELEMENT_NODE) {
                                    Element name = (Element) item1;
                                    System.out.println("CodeID:" + name.getAttribute("CodeID"));
                                    System.out.println("Code :" + name.getElementsByTagName("Code").item(0).getTextContent());
                                    System.out.println("CodeType:" + name.getElementsByTagName("CodeType").item(0).getTextContent());
                                    System.out.println("Description :" + name.getElementsByTagName("Description").item(0).getTextContent());
                                    System.out.println("SystemDefined :" + name.getElementsByTagName("SystemDefined").item(0).getTextContent());
                                    System.out.println("Active :" + name.getElementsByTagName("Active").item(0).getTextContent());
                                }
                            }
                        }
                    }
                }

            }
        } catch (IOException ex) {
            {

            }
//
//            for (int temp = 0; temp < nList.getLength(); temp++) {
//                Node nNode = nList.item(temp);
//                System.out.println("\nCurrent Element :" + nNode.getNodeName());
//
//                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
//                    Element eElement = (Element) nNode;
//                    System.out.println("Student roll no : " + eElement.getAttribute("PublicDatabaseID"));
//                    //     System.out.println("Codes: " + eElement.getElementsByTagName("Codes"));
//                    NodeList CodeTypeList = eElement.getElementsByTagName("CodeType");
//                    System.out.println("CodeType: " + CodeTypeList.getLength());
//                  for (int i = 0; i < CodeTypeList.getLength(); i++) {
//                        Node item = (Node) CodeTypeList.item(i).getChildNodes();
//                        if (item.getNodeType() == Node.ELEMENT_NODE) {
//                            Element eElement1 = (Element) item;
//                            System.out.println("Description :-" + eElement1.getElementsByTagName("Description").item(i).getTextContent());
//                            System.out.println("UserMaintainable :-" + eElement1.getElementsByTagName("UserMaintainable").item(i).getTextContent());
//                            //System.out.println("Code :-" + eElement1.getElementsByTagName("Code").item(0).getTextContent());
//                         //   System.out.println("Description :-" + eElement1.getElementsByTagName("Description").item(0).getTextContent());
//                        }
//                        }
//                    }
//
//                }
        }

    }
}
