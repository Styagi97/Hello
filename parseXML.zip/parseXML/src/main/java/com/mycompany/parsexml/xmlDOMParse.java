/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml;

import java.io.File;
import java.io.IOException;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author admin
 */
public class xmlDOMParse {

    private static final String FILENAME = "C:\\Users\\admin\\Documents\\Shivani\\sample.txt";

    public static void main(String[] args) {

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);

            DocumentBuilder db = dbf.newDocumentBuilder();

            Document doc = db.parse(new File(FILENAME));
            doc.getDocumentElement().normalize();

            System.out.println("Root Element :" + doc.getDocumentElement().getNodeName());
            System.out.println("------");

            // get <staff>
            NodeList list = doc.getElementsByTagName("ChildPlusDataExport");
          //  NodeList CodeType = doc.getElementsByTagName("CodeType");

            for (int j = 0; j < list.getLength(); j++) {
                Node list1 = list.item(j);
                NodeList childNodes = list1.getChildNodes();
            for (int a = 0; a < childNodes.getLength(); a++) {
                Node CodeType1 = childNodes.item(a);
                if (CodeType1.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) CodeType1;
                    System.out.println("Current Element :" + element.getNodeName());
                    System.out.println("Staff Id : " + element.getAttribute("CodeType"));
                    System.out.println("Description : " + element.getElementsByTagName("Description").item(a).getTextContent());
                    System.out.println("UserMaintainable  : " + element.getElementsByTagName("UserMaintainable").item(a).getTextContent());
                    NodeList Code = doc.getElementsByTagName("Code");
                    for (int b = 0; b < Code.getLength(); b++) {
                        Node node1 = Code.item(b);
                        if (node1.getNodeType() == Node.ELEMENT_NODE) {
                            Element element1 = (Element) node1;

                            System.out.println("CodeID  : " + element1.getAttribute("CodeID"));
                            System.out.println("CodeType :" + element1.getElementsByTagName("CodeType").item(b).getTextContent());
                            System.out.println("Description  : " + element1.getElementsByTagName("Description").item(b).getTextContent());
                            System.out.println("SystemDefined :" + element1.getElementsByTagName("SystemDefined").item(b).getTextContent());
                            System.out.println("Active :" + element1.getElementsByTagName("Active").item(b).getTextContent());
                        }
                    }
                }

            }
            }

        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }

    }
}
