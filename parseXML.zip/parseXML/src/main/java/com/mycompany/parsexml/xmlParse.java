/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parsexml;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mycompany.parsexml.myPojo.Root;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 *
 * @author admin
 */
public class xmlParse {

    public static void main(String[] args) throws JsonProcessingException, IOException, SAXException, ParserConfigurationException, TransformerException, JAXBException {
        String mydata = "C:\\Users\\admin\\Downloads\\Sample_Data.xml";
//        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//        InputStream is = new FileInputStream(mydata);
//
//        DocumentBuilder db = dbf.newDocumentBuilder();
//
//        Document doc = db.parse(is);
//        transform(doc, System.out);
//        System.out.println("Serializing to XML...");
//        serializeToXML();
        System.out.println("Deserializing from XML...");
        //   deserializeFromXML();

        JAXBContext context = JAXBContext.newInstance(Root.class);
        Marshaller m = context.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        var bookstore = new Root();
        // Write to System.out
        m.marshal(bookstore, System.out);
//
//        // Write to File
      //  m.marshal(bookstore, new File(mydata)); 
        System.out.println();
        System.out.println("Output from our XML File: ");
        Unmarshaller um = context.createUnmarshaller();
        Root bookstore2 = (Root) um.unmarshal(new FileReader(mydata));
        List<Root> list = (List<Root>) bookstore2.getChildPlusDataExport().getCodes();
        System.out.println(list);
        for (Root book : list) {
            System.out.println("Root: " + book.getChildPlusDataExport()+ " from ");
                 //   + book.getAuthor());
        }
        //    public static void serializeToXML() {
        //        try {
        //            XmlMapper xmlMapper = new XmlMapper();
        //            String xmlString = xmlMapper.writeValueAsString(new Root());
        //
        //            System.out.println(xmlString);
        //            File xmlOutput = new File("serialized.xml");
        //            try ( FileWriter fileWriter = new FileWriter(xmlOutput)) {
        //                fileWriter.write(xmlString);
        //            }
        //        } catch (JsonProcessingException e) {
        //            // handle exception
        //        } catch (IOException e) {
        //            // handle exception
        //        }
        //    }
    }
    public static void deserializeFromXML() {
        try {
            XmlMapper xmlMapper = new XmlMapper();
            Gson gson = new Gson();
//            System.out.println("Name: " + deserializedData.getChildPlusDataExport());
            String readContent = new String(Files.readAllBytes(Paths.get("C:\\Users\\admin\\Downloads\\data (1).xml")));
            System.out.println("what  us" + readContent);
            Root deserializedData = xmlMapper.readValue(readContent, Root.class);
            ObjectMapper mapper = new ObjectMapper();
            String json = mapper.writeValueAsString(deserializedData);

            System.out.println(gson.toJson(json));
        } catch (IOException e) {
        }
    }

    private static void transform(Document doc, OutputStream output)
            throws TransformerException {

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();

        // pretty print
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        transformer.transform(new DOMSource(doc), new StreamResult(output));

    }
}
